# Turtle is a python library used for drawing
# This program will draw a 5-point star

import turtle as t

for i in range(5):
    t.forward(200)
    t.right(144)
    t.forward(200)
    t.left(72)
t.mainloop()