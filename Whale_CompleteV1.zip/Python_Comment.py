# This file is just comments in a Python file
# Anything typed after a number sign in the line becomes a comment